# Project Documentation

```{toctree}
:maxdepth: 2
:caption: Guide
getting-started.md
how-to/index
explanations/index
```

```{toctree}
:maxdepth: 2
:caption: Reference
api/index
architecture/index
```
