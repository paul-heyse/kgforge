from pathlib import Path
import mkdocs_gen_files
from griffe.loader import GriffeLoader

ROOT = Path(__file__).resolve().parents[2]
SRC  = ROOT / "src"

def detect_pkg():
    cands = []
    if SRC.exists():
        cands += [p.parent.name for p in SRC.glob("*/__init__.py")]
    cands += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
    if not cands:
        raise SystemExit("No package found under src/ or root")
    lowers = [c for c in cands if c.islower()] or cands
    return lowers[0]

PKG = detect_pkg()
loader = GriffeLoader(search_paths=[str(SRC if SRC.exists() else ROOT)])
root = loader.load(PKG)

out = Path("api")
with mkdocs_gen_files.open(out / "index.md", "w") as f:
    f.write("# API Reference\n")

def write_node(node):
    rel = node.path.replace(".", "/")
    page = out / rel / "index.md"
    with mkdocs_gen_files.open(page, "w") as f:
        f.write(f"# `{node.path}`\n\n::: {node.path}\n")

for m in root.members.values():
    if m.is_package or m.is_module:
        write_node(m)
