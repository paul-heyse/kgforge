"""
Build a machine-friendly symbol index for AI agents:
- fully qualified name
- kind
- file path (relative to repo)
- start/end lines
- first-line summary doc
Writes: docs/_build/symbols.json
"""
import json, os
from pathlib import Path
from griffe.loader import GriffeLoader

ROOT = Path(__file__).resolve().parents[2]
SRC  = ROOT / "src"

def detect_pkg():
    cands = []
    if SRC.exists():
        cands += [p.parent.name for p in SRC.glob("*/__init__.py")]
    cands += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
    if not cands:
        raise SystemExit("No package found under src/ or project root")
    lowers = [c for c in cands if c.islower()]
    return (lowers[0] if lowers else cands[0])

PKG = os.environ.get("DOCS_PKG", detect_pkg())

loader = GriffeLoader(search_paths=[str(SRC if SRC.exists() else ROOT)])
root = loader.load(PKG)

rows = []
def walk(node):
    for m in node.members.values():
        rows.append({
            "path": m.path,
            "kind": m.kind.value,
            "file": getattr(m, "relative_package_filepath", None),
            "lineno": getattr(m, "lineno", None),
            "endlineno": getattr(m, "endlineno", None),
            "doc": (m.docstring.value.split("\n\n")[0] if getattr(m, "docstring", None) else ""),
        })
        walk(m)
walk(root)

out = ROOT / "docs" / "_build"
out.mkdir(parents=True, exist_ok=True)
(out / "symbols.json").write_text(json.dumps(rows, indent=2), encoding="utf-8")
print(f"Wrote {len(rows)} entries to {out/'symbols.json'}")
