# -*- coding: utf-8 -*-
"""
Agent-first Sphinx configuration
- Static API docs via AutoAPI (no imports)
- Markdown via MyST
- Per-symbol "open in editor" links (linkcode + Griffe)
- Viewable source with line numbers (viewcode)
- JSON builder for machine-readable output
This file is robust to different repo shapes (src/PKG or PKG at root).
"""
import os, sys, subprocess
from pathlib import Path

# --- Project metadata (override via env if you like)
project = os.environ.get("PROJECT_NAME", "Your Project")
author  = os.environ.get("PROJECT_AUTHOR", "Your Team")

# --- Paths
DOCS_DIR = Path(__file__).resolve().parent
ROOT     = DOCS_DIR.parent
SRC_DIR  = ROOT / "src"

def _detect_pkg():
    # pick the first package dir that has an __init__.py, preferring src/
    candidates = []
    if SRC_DIR.exists():
        candidates += [p.parent.name for p in SRC_DIR.glob("*/__init__.py")]
    candidates += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
    if not candidates:
        raise RuntimeError("No Python package found under src/ or project root")
    # Prefer lowercase names if any; else first found
    lowers = [c for c in candidates if c.islower()]
    return (lowers[0] if lowers else candidates[0])

PKG = os.environ.get("DOCS_PKG", _detect_pkg())

# Sphinx searches sys.path when rendering cross-refs; we do not import the package for API parsing.
sys.path.insert(0, str(ROOT))

extensions = [
    "myst_parser",
    "sphinx.ext.napoleon",
    "sphinx.ext.autosummary",
    "sphinx.ext.intersphinx",
    "sphinx.ext.viewcode",
    "sphinx.ext.linkcode",
    "sphinx.ext.graphviz",
    "sphinx.ext.inheritance_diagram",
    "autoapi.extension",            # static API docs (no import)
    "sphinxcontrib.mermaid",
]

# Use whatever theme you prefer; pydata_sphinx_theme is widely used.
html_theme = os.environ.get("SPHINX_THEME", "pydata_sphinx_theme")

# MyST (Markdown) features
myst_enable_extensions = ["colon_fence", "deflist", "linkify"]

# AutoAPI: scan source directory (or root if no src/ folder)
autoapi_type = "python"
autoapi_dirs = [str(SRC_DIR if SRC_DIR.exists() else ROOT)]
autoapi_add_toctree_entry = True
autoapi_options = [
    "members", "undoc-members", "show-inheritance", "special-members", "imported-members"
]

# Show type hints nicely
autodoc_typehints = "description"

# Cross-link to Python stdlib docs
intersphinx_mapping = {
    "python": ("https://docs.python.org/3", {"objects.inv": None}),
}

# Show line numbers in rendered source pages (Sphinx >= 7.2)
viewcode_line_numbers = True

# --- Build deep links per symbol without importing your code (use Griffe)
from griffe.loader import GriffeLoader

_loader = GriffeLoader(search_paths=[str(SRC_DIR if SRC_DIR.exists() else ROOT)])
_root = _loader.load(PKG)

def _lookup(module: str, fullname: str):
    """Return (abs_path, start, end) of a symbol via Griffe; None if not found."""
    node = _root
    # step into requested module
    if module and module != PKG:
        parts = module.split(".")[1:]
        for part in parts:
            node = node.members.get(part, node)
    # step into the object
    for part in (fullname or "").split("."):
        if not part:
            continue
        node = node.members.get(part, node)
    file_rel = getattr(node, "relative_package_filepath", None)
    start    = getattr(node, "lineno", None)
    end      = getattr(node, "endlineno", None)
    if not (file_rel and start):
        return None
    abs_path = (SRC_DIR if SRC_DIR.exists() else ROOT) / file_rel
    return str(abs_path.resolve()), int(start), int(end or start)

# Link modes:
#   DOCS_LINK_MODE=editor (default): vscode://file/<abs>:line:col
#   DOCS_LINK_MODE=github: https://github.com/<org>/<repo>/blob/<sha>/<rel>#Lstart-Lend
LINK_MODE = os.environ.get("DOCS_LINK_MODE", "editor").lower()
EDITOR = os.environ.get("DOCS_EDITOR", "vscode")

def _git_sha():
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(ROOT), text=True).strip()
    except Exception:
        return os.environ.get("DOCS_GITHUB_SHA", "main")

def _github_url(relpath, start, end):
    org  = os.environ.get("DOCS_GITHUB_ORG", "your-org")
    repo = os.environ.get("DOCS_GITHUB_REPO", "your-repo")
    sha  = _git_sha()
    rng  = f"#L{start}-L{end}" if end and end >= start else f"#L{start}"
    return f"https://github.com/{org}/{repo}/blob/{sha}/{relpath}{rng}"

def linkcode_resolve(domain, info):
    if domain != "py" or not info.get("module"):
        return None
    res = _lookup(info["module"], info.get("fullname", ""))
    if not res:
        return None
    abs_path, start, end = res
    if LINK_MODE == "github":
        # compute relative path from repo root
        rel = os.path.relpath(abs_path, ROOT)
        return _github_url(rel, start, end)
    # default: open in editor
    if EDITOR == "vscode":
        return f"vscode://file/{abs_path}:{start}:1"
    elif EDITOR == "pycharm":
        return f"pycharm://open?file={abs_path}&line={start}"
    return None
