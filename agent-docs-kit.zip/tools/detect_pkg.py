from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
SRC  = ROOT / "src"
cands = []
if SRC.exists():
    cands += [p.parent.name for p in SRC.glob("*/__init__.py")]
cands += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
if not cands:
    raise SystemExit(1)
lowers = [c for c in cands if c.islower()] or cands
print(lowers[0])
