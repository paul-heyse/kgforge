"""
Generate package-level README.md files that:
- List top-level classes/functions
- Provide deep links to their start line
- Are compatible with local editor links or GitHub permalinks
After generation, run 'doctoc src/<pkg>' to update TOCs.
"""
import os, subprocess
from pathlib import Path
from griffe.loader import GriffeLoader

ROOT = Path(__file__).resolve().parents[1]
SRC  = ROOT / "src"

def detect_pkg():
    cands = []
    if SRC.exists():
        cands += [p.parent.name for p in SRC.glob("*/__init__.py")]
    cands += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
    if not cands:
        raise SystemExit("No package found under src/ or project root")
    lowers = [c for c in cands if c.islower()] or cands
    return lowers[0]

PKG = os.environ.get("DOCS_PKG", detect_pkg())
LINK_MODE = os.environ.get("DOCS_LINK_MODE", "editor").lower()  # "editor" | "github"
EDITOR = os.environ.get("DOCS_EDITOR", "vscode")

def git_sha():
    try:
        return subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=str(ROOT), text=True).strip()
    except Exception:
        return os.environ.get("DOCS_GITHUB_SHA", "main")

OWNER = os.environ.get("DOCS_GITHUB_ORG", "your-org")
REPO  = os.environ.get("DOCS_GITHUB_REPO", "your-repo")
SHA   = git_sha()

def gh_url(rel, start, end):
    rng = f"#L{start}-L{end}" if end and end >= start else f"#L{start}"
    return f"https://github.com/{OWNER}/{REPO}/blob/{SHA}/{rel}{rng}"

def editor_url(abs_path, start):
    if EDITOR == "vscode":
        return f"vscode://file/{abs_path}:{start}:1"
    elif EDITOR == "pycharm":
        return f"pycharm://open?file={abs_path}&line={start}"
    return None

loader = GriffeLoader(search_paths=[str(SRC if SRC.exists() else ROOT)])
root = loader.load(PKG)

def write_readme(node):
    pkg_dir = (SRC if SRC.exists() else ROOT) / node.path.replace(".", "/")
    readme = pkg_dir / "README.md"
    lines = [f"# `{node.path}`\n\n", "## API\n"]
    for child in node.members.values():
        if child.kind.value in {"class", "function"} and child.lineno:
            abs_path = ((SRC if SRC.exists() else ROOT) / child.relative_package_filepath).resolve()
            if LINK_MODE == "github":
                rel = abs_path.relative_to(ROOT)
                url = gh_url(str(rel), child.lineno, getattr(child, "endlineno", None))
            else:
                url = editor_url(abs_path, child.lineno)
            lines.append(f"- **`{child.path}`** → [source]({url})\n")
    readme.write_text("".join(lines), encoding="utf-8")
    print(f"Wrote {readme}")

for m in root.members.values():
    if m.is_package:
        write_readme(m)
