"""
Create a .importlinter file with a default layered-architecture contract.
Detects the root package automatically (prefers src/<pkg>).
"""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC  = ROOT / "src"

def detect_pkg():
    cands = []
    if SRC.exists():
        cands += [p.parent.name for p in SRC.glob("*/__init__.py")]
    cands += [p.parent.name for p in ROOT.glob("*/__init__.py") if p.parent.name != "docs"]
    if not cands:
        raise SystemExit("No package found under src/ or project root")
    lowers = [c for c in cands if c.islower()] or cands
    return lowers[0]

pkg = detect_pkg()
tmpl = f"""[importlinter]
root_package = {pkg}

[importlinter:contract:layers]
name = Respect layered architecture
type = layers
layers =
    {pkg}.presentation
    {pkg}.domain
    {pkg}.infrastructure
"""
out = ROOT / ".importlinter"
out.write_text(tmpl, encoding="utf-8")
print(f"Wrote {out}")
