"""Interfaces for caching results within the CodeIntel MCP stack."""
