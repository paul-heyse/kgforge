"""Integration tests for CodeIntel MCP components."""
