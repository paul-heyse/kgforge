"""MCP server implementation and tool adapters for CodeIntel."""
