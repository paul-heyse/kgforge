"""MCP tool adapters.

Adapters implement the actual logic for MCP tools, separating
concerns between the MCP interface and business logic.
"""

from __future__ import annotations

__all__ = []
