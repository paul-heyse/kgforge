
"""Answer adapter that wires the end-to-end answer pipeline into an MCP tool."""

from __future__ import annotations

import numpy as np

from kgfoundry_common.logging import get_logger
from codeintel_rev.mcp_server.schemas import AnswerEnvelope as McpAnswerEnvelope, ScopeIn
from codeintel_rev.mcp_server.service_context import get_service_context
from codeintel_rev.pipelines.answerflow import PipelineDeps, run_answer_pipeline

LOGGER = get_logger(__name__)


def answer_query(question: str, *, limit: int = 10, nprobe: int = 64, scope: ScopeIn | None = None) -> McpAnswerEnvelope:
    """Top-level tool handler for Q→A flow.

    Parameters
    ----------
    question : str
        Natural-language question about the repository.
    limit : int
        Max number of snippets to include.
    nprobe : int
        IVF nprobe used during FAISS search (if applicable).
    scope : ScopeIn | None
        Optional scope constraints.

    Returns
    -------
    AnswerEnvelope
        Structured answer with snippets, limits, and confidence.
    """
    ctx = get_service_context()
    # Embed with existing embeddings client
    vec, err = ctx.vllm_client.embed_batch([question])
    from codeintel_rev.io.vllm_chat import ChatClient, ScoreClient
    chat = ChatClient(base_url=ctx.settings.vllm.base_url + "/v1", model=ctx.settings.vllm.chat_model)
    scorer = ScoreClient(base_url=ctx.settings.vllm.base_url + "/v1", model=ctx.settings.vllm.score_model) if ctx.settings.vllm.score_model else None
    if vec is None or vec.shape[0] == 0:  # fallback: zero vector to force text-only retrieval
        LOGGER.warning("Embedding failed; falling back to text-only retrieval", extra={"error": str(err)})
        query_vec = np.zeros((1, ctx.settings.vllm.embedding_dim), dtype=np.float32)
    else:
        query_vec = vec[:1]

    deps = PipelineDeps(faiss=ctx.faiss_manager, duck=ctx.duckdb, chat=chat, scorer=scorer)
    envelope = run_answer_pipeline(
        deps, question, query_vec, scope,
        limit=limit, k_faiss=max(32, limit*4), nprobe=nprobe, k_text=max(32, limit*6),
        rerank_k=min(20, limit*2), synth_tokens=ctx.settings.vllm.synth_max_tokens,
    )
    return envelope
