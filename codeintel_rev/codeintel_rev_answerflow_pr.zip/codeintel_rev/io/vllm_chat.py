
"""Minimal OpenAI-compatible Chat & Score clients for vLLM.

* ChatClient: calls /v1/chat/completions (non-streaming for simplicity).
* ScoreClient: calls /v1/scores (optional cross-encoder reranking).

Use HTTP timeouts and short retries; callers decide higher-level fallbacks.
"""

from __future__ import annotations

import httpx
import msgspec
from typing import Iterable

from kgfoundry_common.logging import get_logger

LOGGER = get_logger(__name__)


class ChatMessage(msgspec.Struct):
    role: str
    content: str


class ChatRequest(msgspec.Struct):
    model: str
    messages: list[ChatMessage]
    temperature: float = 0.2
    max_tokens: int = 256


class Choice(msgspec.Struct):
    index: int
    message: ChatMessage


class ChatResponse(msgspec.Struct):
    choices: list[Choice]


class ScoreRequest(msgspec.Struct):
    model: str
    input: list[str]
    candidate: list[str]
    top_k: int = 10


class ScorePair(msgspec.Struct):
    doc_index: int
    score: float


class ScoreResponse(msgspec.Struct):
    data: list[ScorePair]


class ChatClient:
    def __init__(self, base_url: str, model: str, timeout_s: float = 20.0) -> None:
        self._base = base_url.rstrip("/")
        self._model = model
        self._enc = msgspec.json.Encoder()
        self._dec = msgspec.json.Decoder(type=ChatResponse)
        self._client = httpx.Client(timeout=timeout_s)

    def complete(self, prompt: str, *, max_tokens: int = 256, temperature: float = 0.2) -> str:
        req = ChatRequest(model=self._model, messages=[ChatMessage(role="user", content=prompt)],
                          temperature=temperature, max_tokens=max_tokens)
        resp = self._client.post(f"{self._base}/chat/completions", content=self._enc.encode(req),
                                 headers={"Content-Type": "application/json"})
        resp.raise_for_status()
        out = self._dec.decode(resp.content)
        if not out.choices:
            return ""
        return out.choices[0].message.content

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:  # pragma: no cover
            pass


class ScoreClient:
    def __init__(self, base_url: str, model: str, timeout_s: float = 20.0) -> None:
        self._base = base_url.rstrip("/")
        self._model = model
        self._enc = msgspec.json.Encoder()
        self._dec = msgspec.json.Decoder(type=ScoreResponse)
        self._client = httpx.Client(timeout=timeout_s)

    def score(self, *, query: str, passages: list[str], top_k: int = 10) -> list[ScorePair]:
        req = ScoreRequest(model=self._model, input=[query], candidate=passages, top_k=top_k)
        resp = self._client.post(f"{self._base}/scores", content=self._enc.encode(req),
                                 headers={"Content-Type": "application/json"})
        resp.raise_for_status()
        out = self._dec.decode(resp.content)
        return out.data

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:  # pragma: no cover
            pass
