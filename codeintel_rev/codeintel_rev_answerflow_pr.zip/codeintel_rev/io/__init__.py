"""Storage and external service adapters for CodeIntel MCP."""
