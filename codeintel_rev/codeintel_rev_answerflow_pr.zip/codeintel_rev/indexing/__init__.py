"""SCIP parsing and chunking utilities for repository indexing."""
