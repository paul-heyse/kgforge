"""CodeIntel MCP package exposing server, indexing, and retrieval APIs."""
