"""FastAPI application wiring for the CodeIntel MCP server."""
