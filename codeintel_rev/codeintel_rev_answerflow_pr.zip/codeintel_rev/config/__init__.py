"""Configuration loading and environment settings for CodeIntel MCP."""
