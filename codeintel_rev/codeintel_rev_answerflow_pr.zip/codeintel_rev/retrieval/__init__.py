"""Hybrid retrieval algorithms for the CodeIntel MCP stack."""
